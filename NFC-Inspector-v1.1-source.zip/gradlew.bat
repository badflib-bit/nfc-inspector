@echo off
set APP_HOME=%~dp0
if not exist "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" (
  echo Missing gradle-wrapper.jar. Install Gradle 8.9 and run: gradle wrapper --gradle-version 8.9
  exit /b 1
)
java %JAVA_OPTS% -classpath "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
