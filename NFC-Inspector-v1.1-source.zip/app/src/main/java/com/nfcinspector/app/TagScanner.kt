package com.nfcinspector.app

import android.content.Context
import android.content.pm.PackageManager
import android.nfc.Tag
import android.nfc.tech.IsoDep
import android.nfc.tech.MifareClassic
import android.nfc.tech.MifareUltralight
import android.nfc.tech.Ndef
import android.nfc.tech.NfcA
import android.nfc.tech.NfcB
import android.nfc.tech.NfcF
import android.nfc.tech.NfcV
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** A diagnostic snapshot of public tag metadata; NO authentication or block reading. */
data class ScanRecord(
    val timestamp: Long,
    val label: String,
    val uid: String,
    val techs: List<String>,
    val kind: String,
    val assessment: String,
    val assessmentDetail: String,
    val details: List<Pair<String, String>>
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("timestamp", timestamp)
        put("label", label)
        put("uid", uid)
        put("techs", JSONArray(techs))
        put("kind", kind)
        put("assessment", assessment)
        put("assessmentDetail", assessmentDetail)
        val arr = JSONArray()
        details.forEach { (key, value) ->
            arr.put(JSONObject().put("key", key).put("value", value))
        }
        put("details", arr)
    }

    /** Deliberately omits the UID and NFC payloads from the copied report. */
    fun safeReport(hce: Boolean, nfcFhce: Boolean): String = buildString {
        appendLine("NFC Inspector v1.2.1 — диагностика")
        appendLine("Дата: ${formattedTime(timestamp)}")
        appendLine("Тип: $kind")
        appendLine("Технологии: ${techs.joinToString(", ")}")
        appendLine("HCE ISO-DEP на устройстве: ${if (hce) "есть" else "нет"}")
        appendLine("HCE NFC-F на устройстве: ${if (nfcFhce) "есть" else "нет"}")
        appendLine("Оценка: $assessment")
        appendLine("Пояснение: $assessmentDetail")
        details.forEach { (key, value) -> appendLine("$key: $value") }
        appendLine("UID намеренно исключён из общего отчёта.")
    }

    companion object {
        fun fromJson(o: JSONObject): ScanRecord {
            val techArray = o.optJSONArray("techs") ?: JSONArray()
            val detailArray = o.optJSONArray("details") ?: JSONArray()
            return ScanRecord(
                timestamp = o.optLong("timestamp", 0L),
                label = o.optString("label", "Карта"),
                uid = o.optString("uid", ""),
                techs = (0 until techArray.length()).map { techArray.optString(it) },
                kind = o.optString("kind", "Неизвестная карта"),
                assessment = o.optString("assessment", "Не определено"),
                assessmentDetail = o.optString("assessmentDetail", ""),
                details = (0 until detailArray.length()).mapNotNull { i ->
                    val pair = detailArray.optJSONObject(i) ?: return@mapNotNull null
                    pair.optString("key") to pair.optString("value")
                }
            )
        }
    }
}

fun formattedTime(time: Long): String =
    SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault()).format(Date(time))

private fun ByteArray.hex(): String = joinToString(":") { "%02X".format(it.toInt() and 0xFF) }

object TagScanner {
    fun scan(tag: Tag, context: Context, label: String): ScanRecord {
        val raw = tag.techList.map { it.substringAfterLast('.') }
        val techs = raw.sorted()
        val fields = mutableListOf<Pair<String, String>>()
        val uid = tag.id?.hex() ?: "Нет данных"
        val hce = context.packageManager.hasSystemFeature(PackageManager.FEATURE_NFC_HOST_CARD_EMULATION)
        val nfcFhce = context.packageManager.hasSystemFeature(PackageManager.FEATURE_NFC_HOST_CARD_EMULATION_NFCF)

        NfcA.get(tag)?.let { nfc ->
            fields.add("ATQA (NFC-A)" to nfc.atqa.hex())
            fields.add("SAK (NFC-A)" to "0x%02X".format(nfc.sak.toInt() and 0xFF))
        }
        NfcB.get(tag)?.let { nfc ->
            fields.add("Application Data (NFC-B)" to nfc.applicationData.hex())
            fields.add("Protocol Info (NFC-B)" to nfc.protocolInfo.hex())
        }
        NfcF.get(tag)?.let { nfc ->
            fields.add("System Code (NFC-F)" to nfc.systemCode.hex())
            fields.add("Manufacturer (NFC-F)" to nfc.manufacturer.hex())
        }
        NfcV.get(tag)?.let { nfc ->
            fields.add("DSF ID (NFC-V)" to "0x%02X".format(nfc.dsfId.toInt() and 0xFF))
            fields.add("Response Flags (NFC-V)" to "0x%02X".format(nfc.responseFlags.toInt() and 0xFF))
        }
        IsoDep.get(tag)?.let { iso ->
            iso.historicalBytes?.let { fields.add("Historical Bytes (ISO-DEP)" to it.hex()) }
            iso.hiLayerResponse?.let { fields.add("Hi-layer Response (ISO-DEP)" to it.hex()) }
        }
        MifareClassic.get(tag)?.let { classic ->
            val name = when (classic.type) {
                MifareClassic.TYPE_CLASSIC -> "Classic"
                MifareClassic.TYPE_PLUS -> "Plus"
                MifareClassic.TYPE_PRO -> "Pro"
                else -> "Неизвестно"
            }
            fields.add("MIFARE Type" to name)
            fields.add("Размер MIFARE" to "${classic.size} байт")
        }
        MifareUltralight.get(tag)?.let { ultralight ->
            val name = when (ultralight.type) {
                MifareUltralight.TYPE_ULTRALIGHT -> "Ultralight"
                MifareUltralight.TYPE_ULTRALIGHT_C -> "Ultralight C"
                else -> "Неизвестно / NTAG-подобная"
            }
            fields.add("MIFARE Ultralight" to name)
        }
        Ndef.get(tag)?.let { ndef ->
            // Read only NDEF metadata already populated by Android. No protected content.
            fields.add("NDEF type" to ndef.type)
            fields.add("NDEF max size" to "${ndef.maxSize} байт")
            fields.add("NDEF writable" to if (ndef.isWritable) "Да" else "Нет")
            fields.add("NDEF records (cached)" to
                (ndef.cachedNdefMessage?.records?.size?.toString() ?: "Не определено"))
        }

        val kind = when {
            "MifareClassic" in raw -> "MIFARE Classic / Plus"
            "IsoDep" in raw -> "ISO-DEP (ISO 14443-4)"
            "MifareUltralight" in raw -> "MIFARE Ultralight / NTAG"
            "NfcV" in raw -> "NFC-V (ISO 15693)"
            "NfcF" in raw -> "NFC-F (FeliCa-совместимая)"
            "NfcB" in raw -> "NFC-B"
            "NfcA" in raw -> "NFC-A"
            else -> "NFC-метка, тип не определён"
        }

        val (assessment, explanation) = when {
            "MifareClassic" in raw ->
                "Стандартная HCE-эмуляция не подходит" to
                    "Обычный Android HCE не эмулирует MIFARE Classic. Чтение UID не даёт доступа к защищённым секторам."
            "IsoDep" in raw && hce ->
                "Совместим протокол ISO-DEP — условно" to
                    "Телефон поддерживает HCE/APDU, однако реальная эмуляция требует известных команд, разрешений и действительных ключей приложения. Это не означает, что карта клонируется."
            "IsoDep" in raw ->
                "HCE ISO-DEP на телефоне недоступна" to
                    "Карта поддерживает ISO-DEP, но система не объявляет поддержку HCE."
            "NfcF" in raw && nfcFhce ->
                "Возможна разработка NFC-F HCE" to
                    "Устройство заявляет NFC-F HCE, но совместимость с конкретной системой доступа и её проверками неизвестна."
            "NfcF" in raw ->
                "NFC-F HCE не подтверждена" to
                    "Система не объявляет поддержку NFC-F HCE; обычная ISO-DEP HCE для этого протокола не подходит."
            else ->
                "Нет универсальной эмуляции" to
                    "Сканер умеет распознавать технологию и открытые метаданные. Стандартный Android HCE не копирует произвольный UID, формат памяти или радиосигнал этой карты."
        }
        return ScanRecord(
            timestamp = System.currentTimeMillis(), label = label,
            uid = uid, techs = techs, kind = kind,
            assessment = assessment, assessmentDetail = explanation, details = fields
        )
    }
}

class ScanStorage(context: Context) {
    private val prefs = context.getSharedPreferences("scans_local_v1", Context.MODE_PRIVATE)

    fun all(): List<ScanRecord> = try {
        val json = JSONArray(prefs.getString("scans", "[]"))
        (0 until json.length()).mapNotNull { i ->
            runCatching { ScanRecord.fromJson(json.getJSONObject(i)) }.getOrNull()
        }
    } catch (_: Exception) {
        emptyList()
    }

    fun add(record: ScanRecord) {
        val updated = (listOf(record) + all()).take(50)
        save(updated)
    }

    fun updateLabel(record: ScanRecord, name: String) {
        save(all().map { entry ->
            if (entry.timestamp == record.timestamp && entry.uid == record.uid) {
                entry.copy(label = name.take(60))
            } else entry
        })
    }

    fun delete(record: ScanRecord) {
        save(all().filterNot { it.timestamp == record.timestamp && it.uid == record.uid })
    }

    private fun save(records: List<ScanRecord>) {
        val result = JSONArray()
        records.forEach { result.put(it.toJson()) }
        prefs.edit().putString("scans", result.toString()).apply()
    }
}
