package com.nfcinspector.app

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

/**
 * Short-lived BLE advertisement discovery. Never connects, pairs, writes, or transmits
 * application-level commands. Android's radio may emit normal BLE scan requests.
 * Hardware addresses are held only in RAM for correlation between two sessions;
 * they are never displayed, persisted, or exported.
 */
class BleProbe(
    private val context: Context,
    private val onUpdate: () -> Unit
) {
    enum class Phase { FAR, NEAR }

    data class Device(
        val key: String,               // Private, transient Bluetooth address; never show/copy.
        val token: String,             // Session-local pseudonym (BLE-01 etc.).
        val name: String,
        val rssi: Int,
        val samples: Int,
        val services: List<String>,
        val manufacturers: List<String>
    )

    private data class Accum(
        val key: String,
        val token: String,
        var name: String = "Без имени",
        val rssiSamples: MutableList<Int> = mutableListOf(),
        var services: List<String> = emptyList(),
        var manufacturers: List<String> = emptyList()
    ) {
        fun snapshot(): Device {
            val sorted = rssiSamples.sorted()
            val median = if (sorted.isEmpty()) -127 else sorted[sorted.size / 2]
            return Device(key, token, name, median, rssiSamples.size, services, manufacturers)
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val tokens = LinkedHashMap<String, String>()
    private val readings = LinkedHashMap<String, Accum>()
    private val maxDevices = 150
    private val windowMs = 14_000L
    private var radio: BluetoothLeScanner? = null
    private var callback: ScanCallback? = null
    private var deadline = 0L
    private val uiVersion = AtomicInteger(0)
    private var lastRenderMs = 0L
    private val refresh = Runnable {
        if (running) {
            lastRenderMs = SystemClock.elapsedRealtime()
            onUpdate()
        }
    }
    private val finishTask = Runnable { stop() }

    var phase: Phase? = null
        private set
    var running = false
        private set
    var status = "Поиск ещё не запускался"
        private set
    var far: List<Device> = emptyList()
        private set
    var near: List<Device> = emptyList()
        private set

    fun hasBleHardware(): Boolean = context.packageManager.hasSystemFeature("android.hardware.bluetooth_le")

    @SuppressLint("MissingPermission")
    fun isBluetoothOn(): Boolean = try {
        manager?.adapter?.isEnabled == true
    } catch (_: SecurityException) {
        false
    }

    fun current(): List<Device> = readings.values.map { it.snapshot() }.sortedByDescending { it.rssi }

    fun secondsRemaining(): Int = if (!running) 0 else
        ((deadline - SystemClock.elapsedRealtime() + 999) / 1000).toInt().coerceAtLeast(0)

    @SuppressLint("MissingPermission") // Checked by Activity before calling start().
    fun start(next: Phase): String? {
        if (running) stop()
        if (!hasBleHardware()) return "Этот телефон не поддерживает Bluetooth LE"
        if (!isBluetoothOn()) return "Включите Bluetooth в настройках"
        val scanner = manager?.adapter?.bluetoothLeScanner ?: return "BLE-сканер недоступен"
        readings.clear()
        phase = next
        deadline = SystemClock.elapsedRealtime() + windowMs
        lastRenderMs = 0
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                handler.post { addResult(result) }
            }

            override fun onBatchScanResults(results: MutableList<ScanResult>) {
                handler.post { results.forEach { addResult(it) } }
            }

            override fun onScanFailed(errorCode: Int) {
                handler.post {
                    if (running) stop("Ошибка BLE-сканирования: $errorCode")
                }
            }
        }
        return try {
            scanner.startScan(
                null,
                ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(),
                cb
            )
            radio = scanner
            callback = cb
            running = true
            status = if (next == Phase.FAR) "Идёт замер вдали от двери" else "Идёт замер у замка"
            handler.postDelayed(finishTask, windowMs)
            onUpdate()
            null
        } catch (e: Exception) {
            radio = null
            callback = null
            running = false
            phase = null
            "Не удалось начать BLE-сканирование: ${e.javaClass.simpleName}"
        }
    }

    @SuppressLint("MissingPermission")
    private fun addResult(result: ScanResult) {
        if (!running) return
        val address = try { result.device.address } catch (_: SecurityException) { return }
        if (address.isBlank()) return
        val item = readings[address] ?: run {
            if (readings.size >= maxDevices) return
            val token = tokens.getOrPut(address) { "BLE-%02d".format(tokens.size + 1) }
            Accum(address, token).also { readings[address] = it }
        }
        val name = try {
            result.scanRecord?.deviceName ?: result.device.name
        } catch (_: SecurityException) {
            result.scanRecord?.deviceName
        }
        if (!name.isNullOrBlank()) item.name = name.replace('\n', ' ').replace('\r', ' ')
                .replace(Regex("(?i)([0-9a-f]{2}:){5}[0-9a-f]{2}"), "[MAC скрыт]").take(50)
        if (item.rssiSamples.size < 50) item.rssiSamples.add(result.rssi)
        result.scanRecord?.serviceUuids?.let { uuids ->
            if (uuids.isNotEmpty()) item.services = uuids.take(4).map { it.uuid.toString() }
        }
        result.scanRecord?.manufacturerSpecificData?.let { data ->
            if (data.size() > 0) {
                item.manufacturers = (0 until minOf(data.size(), 5)).map { index ->
                    "0x%04X".format(data.keyAt(index))
                }
            }
        }
        val now = SystemClock.elapsedRealtime()
        if (now - lastRenderMs >= 900L && uiVersion.getAndIncrement() % 4 == 0) {
            handler.removeCallbacks(refresh)
            handler.postDelayed(refresh, 200L)
        }
    }

    @SuppressLint("MissingPermission")
    fun stop(message: String? = null) {
        handler.removeCallbacks(finishTask)
        handler.removeCallbacks(refresh)
        val wasRunning = running
        running = false
        if (wasRunning) {
            try { callback?.let { radio?.stopScan(it) } } catch (_: Exception) { }
            val completed = current()
            when (phase) {
                Phase.FAR -> far = completed
                Phase.NEAR -> near = completed
                null -> Unit
            }
            status = message ?: "Замер завершён: ${completed.size} устройств"
        }
        callback = null
        radio = null
        onUpdate()
    }

    fun clear() {
        if (running) stop()
        phase = null
        far = emptyList()
        near = emptyList()
        readings.clear()
        tokens.clear()
        status = "Результаты очищены"
        onUpdate()
    }

    /** No radio addresses, advertising payloads, or other sensitive raw data. */
    fun safeReport(): String {
        val farMap = far.associateBy { it.key }
        val nearMap = near.associateBy { it.key }
        return buildString {
            appendLine("NFC Inspector v1.2 — BLE диагностика (без MAC-адресов)")
            appendLine("Дата: ${SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())}")
            appendLine("Телефон: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
            appendLine("Замер вдали: ${far.size} устройств; у замка: ${near.size} устройств")
            appendLine("RSSI — приблизительный уровень сигнала, не подтверждение производителя.")
            if (near.isEmpty()) appendLine("Замер у замка пока не сделан или не обнаружены устройства.")
            near.sortedByDescending { it.rssi }.take(20).forEach { device ->
                val previous = farMap[device.key]
                val change = previous?.let { device.rssi - it.rssi }
                appendLine("${device.token} | ${device.name} | рядом ${device.rssi} dBm" +
                    (if (change != null) " | изменение ${if (change > 0) "+" else ""}${change} dB" else " | вдали нет") +
                    " | пакетов ${device.samples}")
                if (device.services.isNotEmpty()) appendLine("  Service UUIDs: ${device.services.joinToString(", ")}")
                if (device.manufacturers.isNotEmpty()) appendLine("  Manufacturer IDs: ${device.manufacturers.joinToString(", ")}")
            }
            val onlyFar = far.filterNot { nearMap.containsKey(it.key) }
            if (onlyFar.isNotEmpty()) appendLine("Только вдали: ${onlyFar.size} устройств")
            appendLine("MAC-адреса и сырые BLE-пакеты исключены. Результат не доказывает наличие Bluetooth в замке.")
        }
    }
}
