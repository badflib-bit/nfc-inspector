package com.nfcinspector.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.EditText
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity(), NfcAdapter.ReaderCallback {
    private val bg = Color.rgb(16, 21, 31)
    private val card = Color.rgb(26, 34, 47)
    private val elevated = Color.rgb(35, 46, 63)
    private val border = Color.rgb(54, 68, 84)
    private val textPrimary = Color.rgb(242, 248, 252)
    private val textMuted = Color.rgb(166, 182, 196)
    private val accent = Color.rgb(66, 224, 188)
    private val warn = Color.rgb(252, 190, 99)

    private lateinit var storage: ScanStorage
    private lateinit var ble: BleProbe
    private val bluetoothPermissionRequest = 223
    private var requestedBlePhase: BleProbe.Phase? = null
    private var adapter: NfcAdapter? = null
    private var selected: ScanRecord? = null
    private var scanning = true
    private var resumed = false
    private var lastSeen = ""
    private var lastSeenAt = 0L
    private lateinit var container: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        adapter = NfcAdapter.getDefaultAdapter(this)
        storage = ScanStorage(this)
        ble = BleProbe(this) {
            if (resumed) render()
        }
        selected = storage.all().firstOrNull()

        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            setFillViewport(true)
            clipToPadding = false
        }
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(32))
        }
        scroll.addView(container)
        setContentView(scroll)
        if (Build.VERSION.SDK_INT >= 35) {
            scroll.setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(
                    WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars()
                )
                view.setPadding(0, bars.top, 0, bars.bottom)
                insets
            }
        }
        render()
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        updateReaderMode()
        render()
    }

    override fun onPause() {
        // No scan is allowed to continue in the background.
        resumed = false
        if (ble.running) ble.stop("Поиск остановлен при сворачивании приложения")
        runCatching { adapter?.disableReaderMode(this) }
        super.onPause()
    }

    private fun updateReaderMode() {
        val nfc = adapter ?: return
        if (!resumed) return
        if (!scanning || !nfc.isEnabled) {
            runCatching { nfc.disableReaderMode(this) }
            return
        }
        val flags = NfcAdapter.FLAG_READER_NFC_A or
            NfcAdapter.FLAG_READER_NFC_B or
            NfcAdapter.FLAG_READER_NFC_F or
            NfcAdapter.FLAG_READER_NFC_V or
            NfcAdapter.FLAG_READER_NFC_BARCODE
        runCatching { nfc.enableReaderMode(this, this, flags, null) }
            .onFailure {
                Toast.makeText(this, "Не удалось включить чтение NFC", Toast.LENGTH_SHORT).show()
            }
    }

    override fun onTagDiscovered(tag: Tag) {
        // Called off the main/UI thread by Android.
        val uid = tag.id?.joinToString(":") { "%02X".format(it.toInt() and 0xFF) } ?: "no-uid"
        val now = System.currentTimeMillis()
        synchronized(this) {
            if (uid == lastSeen && now - lastSeenAt < 1600) return
            lastSeen = uid
            lastSeenAt = now
        }
        val record = runCatching {
            TagScanner.scan(tag, applicationContext, "Карта ${storage.all().size + 1}")
        }.getOrElse { exception ->
            runOnUiThread {
                Toast.makeText(this, "Ошибка чтения: ${exception.message}", Toast.LENGTH_LONG).show()
            }
            return
        }
        // Storage is application-private; callback is on a binder background thread.
        storage.add(record)
        runOnUiThread {
            selected = record
            render()
            Toast.makeText(this, "Карта распознана и сохранена", Toast.LENGTH_SHORT).show()
        }
    }

    private fun render() {
        container.removeAllViews()
        container.text("NFC INSPECTOR", 13, accent, true, 2)
        container.text("Диагностика карт", 27, textPrimary, true, 10)
        container.text("Считывание открытых NFC-метаданных без изменения карты.", 14, textMuted, false, 18)

        val available = adapter != null
        val enabled = available && adapter?.isEnabled == true
        val hce = packageManager.hasSystemFeature(PackageManager.FEATURE_NFC_HOST_CARD_EMULATION)
        val nfcFhce = packageManager.hasSystemFeature(PackageManager.FEATURE_NFC_HOST_CARD_EMULATION_NFCF)
        panel {
            row("NFC", when {
                !available -> "Нет NFC-контроллера"
                enabled -> "Включён"
                else -> "Выключен"
            }, if (enabled) accent else warn)
            row("HCE / ISO-DEP", if (hce) "Поддерживается" else "Не заявлена", if (hce) accent else warn)
            row("HCE / NFC-F", if (nfcFhce) "Поддерживается" else "Не заявлена", if (nfcFhce) accent else warn)
            row("Телефон", "${Build.MANUFACTURER} ${Build.MODEL}", textMuted)
        }
        space(14)
        panel {
            text("СКАНЕР", 13, accent, true, 8)
            text(when {
                !available -> "NFC недоступен на этом устройстве"
                !enabled -> "Включите NFC в настройках"
                scanning -> "Приложите карту к телефону"
                else -> "Сканирование приостановлено"
            }, 20, textPrimary, true, 8)
            text("Держите карту неподвижно около NFC-антенны. Приложение автоматически сохранит результат.",
                14, textMuted, false, 14)
            if (!enabled && available) {
                action("Открыть настройки NFC", true) {
                    runCatching { startActivity(Intent(Settings.ACTION_NFC_SETTINGS)) }
                        .onFailure { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
                }
            } else if (enabled) {
                action(if (scanning) "Приостановить сканирование" else "Возобновить сканирование", true) {
                    scanning = !scanning
                    updateReaderMode()
                    render()
                }
            }
        }
        space(18)
        renderBleSection()
        space(18)
        container.text("ПОСЛЕДНЯЯ КАРТА", 12, textMuted, true, 10)
        val item = selected
        if (item == null) {
            panel { text("Сканирований пока нет", 16, textMuted, false, 4) }
        } else {
            panel {
                text(item.label, 21, textPrimary, true, 5)
                text(formattedTime(item.timestamp), 12, textMuted, false, 14)
                text("Тип карты", 12, textMuted, false, 3)
                text(item.kind, 17, textPrimary, true, 13)
                row("UID (только чтение)", item.uid, textMuted)
                text("Технологии", 12, textMuted, false, 5)
                text(item.techs.joinToString(" · "), 14, textPrimary, false, 12)
                divider()
                text("ОЦЕНКА СОВМЕСТИМОСТИ", 12, accent, true, 7)
                text(item.assessment, 17, textPrimary, true, 8)
                text(item.assessmentDetail, 14, textMuted, false, 14)
                if (item.details.isNotEmpty()) {
                    divider()
                    text("ПОЛУЧЕННЫЕ ПАРАМЕТРЫ", 12, accent, true, 8)
                    item.details.forEach { (name, value) -> row(name, value, textMuted) }
                }
                space(8)
                action("Переименовать карту", false) {
                    val field = EditText(this@MainActivity).apply {
                        setSingleLine(true)
                        setText(item.label)
                        selectAll()
                        setPadding(dp(24), dp(16), dp(24), dp(16))
                    }
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Название карты")
                        .setView(field)
                        .setPositiveButton("Сохранить") { _, _ ->
                            val name = field.text.toString().trim().take(60)
                            if (name.isNotEmpty()) {
                                storage.updateLabel(item, name)
                                selected = item.copy(label = name)
                                render()
                            }
                        }
                        .setNegativeButton("Отмена", null)
                        .show()
                }
                action("Скопировать диагностику (без UID)", true) {
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText(
                        "NFC Inspector", item.safeReport(hce, nfcFhce)
                    ))
                    Toast.makeText(this@MainActivity, "Диагностика скопирована", Toast.LENGTH_SHORT).show()
                }
                action("Удалить эту запись", false) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Удалить сканирование?")
                        .setMessage("Запись исчезнет из памяти приложения. Данные исходной карты не изменятся.")
                        .setPositiveButton("Удалить") { _, _ ->
                            storage.delete(item)
                            selected = storage.all().firstOrNull()
                            render()
                        }
                        .setNegativeButton("Отмена", null)
                        .show()
                }
            }
        }
        space(18)
        container.text("ИСТОРИЯ · ${storage.all().size}/50", 12, textMuted, true, 10)
        val records = storage.all()
        if (records.isEmpty()) {
            container.text("Сканирования будут храниться локально в приложении.", 13, textMuted, false, 10)
        } else {
            records.forEach { r ->
                val holder = panel {
                    text(r.kind, 15, textPrimary, true, 4)
                    text(formattedTime(r.timestamp), 12, textMuted, false, 4)
                    if (r.timestamp == selected?.timestamp) {
                        text("Открыта", 11, accent, true, 0)
                    }
                }
                holder.setOnClickListener {
                    selected = r
                    render()
                }
                space(8)
            }
        }
        space(10)
        container.text("Конфиденциальность: NFC-сканирования хранятся локально. BLE-результаты — только в оперативной памяти, без MAC в отчётах. Нет подключения к BLE-устройствам, чтения защищённых NFC-секторов или эмуляции.",
            12, textMuted, false, 10)
        container.text("v1.2.1 · NFC + BLE диагностика", 12, accent, true, 8)
    }

    private fun blePermissions(): Array<String> = if (Build.VERSION.SDK_INT >= 31) {
        arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
    } else {
        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    private fun hasBlePermissions(): Boolean = blePermissions().all {
        checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestBle(phase: BleProbe.Phase) {
        if (!hasBlePermissions()) {
            requestedBlePhase = phase
            requestPermissions(blePermissions(), bluetoothPermissionRequest)
            return
        }
        if (!ble.isBluetoothOn()) {
            Toast.makeText(this, "Включите Bluetooth и повторите поиск", Toast.LENGTH_LONG).show()
            runCatching { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
            return
        }
        ble.start(phase)?.let { message ->
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }
        render()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == bluetoothPermissionRequest) {
            val wanted = requestedBlePhase
            requestedBlePhase = null
            if (hasBlePermissions() && wanted != null) {
                requestBle(wanted)
            } else {
                Toast.makeText(this, "Для BLE-поиска необходимо разрешение на устройства поблизости и местоположение", Toast.LENGTH_LONG).show()
                render()
            }
        }
    }

    private fun isLocationServiceOn(): Boolean {
        val location = getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            ?: return false
        return try {
            if (Build.VERSION.SDK_INT >= 28) location.isLocationEnabled
            else location.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                location.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        } catch (_: Exception) {
            false
        }
    }

    private fun renderBleSection() {
        container.text("BLUETOOTH LE · ПОИСК УСТРОЙСТВ", 12, accent, true, 9)
        panel {
            text("Проверка наличия BLE рядом с ORBITA", 19, textPrimary, true, 10)
            val locationOn = isLocationServiceOn()
            text("Геолокация системы: ${if (locationOn) "включена" else "выключена"}",
                13, if (locationOn) accent else warn, true, 6)
            if (!locationOn) {
                text("Включите системное местоположение: на некоторых версиях Android/HyperOS BLE-поиск не возвращает устройства при выключенной геолокации.",
                    13, warn, false, 8)
                action("Открыть настройки местоположения", false) {
                    startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                }
            }
            text("Два коротких замера: сначала в 4–6 м от двери, затем возле замка. Сравнение уровней сигнала помогает найти кандидатов, но не определяет их однозначно.",
                13, textMuted, false, 12)
            text("Поиск только по BLE-рекламе. Без подключений, сопряжения, команд замку и записи данных. Android может отправлять стандартные поисковые запросы BLE.",
                12, textMuted, false, 12)
            if (!ble.hasBleHardware()) {
                text("Bluetooth LE недоступен на устройстве", 15, warn, true, 8)
            } else if (!hasBlePermissions()) {
                text("Для поиска нужны разрешения Bluetooth и местоположения. GPS не считывается; разрешение требуется для сравнения близости BLE-устройств.",
                    13, warn, false, 8)
                action("Разрешить BLE-поиск", true) { requestBle(BleProbe.Phase.FAR) }
            } else if (!ble.isBluetoothOn()) {
                text("Bluetooth выключен", 15, warn, true, 8)
                action("Открыть настройки Bluetooth", true) {
                    startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                }
            } else {
                text(ble.status, 14, if (ble.running) accent else textMuted, true, 8)
                if (ble.running) {
                    text("Найдено сейчас: ${ble.current().size} · Осталось около ${ble.secondsRemaining()} с",
                        13, textPrimary, false, 10)
                    action("Завершить замер", false) { ble.stop() }
                } else {
                    action("1. Замер вдали от двери (14 с)", true) { requestBle(BleProbe.Phase.FAR) }
                    action("2. Замер рядом с замком (14 с)", true) { requestBle(BleProbe.Phase.NEAR) }
                }
                if (ble.farCompleted || ble.nearCompleted) {
                    row("Замер вдали", if (ble.farCompleted) "${ble.far.size} BLE-устройств" else "не проводился", textPrimary)
                    row("Замер у двери", if (ble.nearCompleted) "${ble.near.size} BLE-устройств" else "не проводился", textPrimary)
                    if (ble.nearCompleted && ble.near.isEmpty()) {
                        text("У замка не обнаружено BLE-рекламы. Это не доказывает отсутствия Bluetooth-модуля.",
                            13, warn, false, 8)
                    }
                    action("Скопировать BLE-отчёт (без MAC)", false) {
                        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("BLE Inspector", ble.safeReport()))
                        Toast.makeText(this@MainActivity, "BLE-отчёт скопирован", Toast.LENGTH_SHORT).show()
                    }
                    if (!ble.running) action("Очистить BLE-замеры", false) { ble.clear() }
                }
            }
            val showing = if (ble.running) ble.current() else ble.near
            if (showing.isNotEmpty()) {
                divider()
                text("${if (ble.running) "НАЙДЕНО СЕЙЧАС" else "УСТРОЙСТВА У ЗАМКА"}", 12, accent, true, 8)
                val farMap = ble.far.associateBy { it.key }
                showing.sortedByDescending { it.rssi }.take(18).forEach { dev ->
                    val previous = farMap[dev.key]
                    val delta = previous?.let { dev.rssi - it.rssi }
                    val match = dev.name.contains("orbita", ignoreCase = true)
                    text("${dev.token} · ${dev.name}", 14, if (match) accent else textPrimary, true, 3)
                    text("RSSI ${dev.rssi} dBm · наблюдений ${dev.samples}" +
                        if (delta != null && !ble.running) " · изменение ${if (delta > 0) "+" else ""}${delta} dB" else "",
                        12, textMuted, false, 3)
                    if (dev.services.isNotEmpty()) {
                        text("Service UUID: ${dev.services.joinToString(", ")}", 11, textMuted, false, 3)
                    }
                    if (dev.manufacturers.isNotEmpty()) {
                        text("Manufacturer ID: ${dev.manufacturers.joinToString(", ")}", 11, textMuted, false, 8)
                    }
                    if (match) text("Имя похоже на ORBITA; принадлежность замку не подтверждена", 11, warn, false, 8)
                    divider()
                }
                if (showing.size > 18) text("Показаны 18 самых сильных сигналов из ${showing.size}", 12, textMuted, false, 4)
            }
            text("Важно: отсутствие BLE-устройства не означает, что у замка нет Bluetooth. Модуль может не передавать рекламу или использовать скрытые/случайные идентификаторы.",
                12, textMuted, false, 5)
        }
    }

    private fun panel(content: LinearLayout.() -> Unit): LinearLayout {
        val pane = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(card, 18, border)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        container.addView(pane, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        pane.content()
        return pane
    }

    private fun LinearLayout.text(
        value: String, size: Int, color: Int, bold: Boolean, bottom: Int
    ): TextView = TextView(this@MainActivity).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        setLineSpacing(dp(2).toFloat(), 1f)
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(bottom) }
        this@text.addView(this)
    }

    private fun LinearLayout.row(name: String, value: String, valueColor: Int) {
        text(name, 12, textMuted, false, 3)
        text(value, 14, valueColor, true, 13)
    }

    private fun LinearLayout.action(value: String, primary: Boolean, click: () -> Unit) {
        val button = Button(this@MainActivity).apply {
            text = value
            textSize = 13.5f
            isAllCaps = false
            setTextColor(if (primary) bg else textPrimary)
            background = shape(if (primary) accent else elevated, 12, if (primary) accent else border)
            minHeight = dp(49)
            setPadding(dp(10), dp(11), dp(10), dp(11))
            setOnClickListener { click() }
        }
        addView(button, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(8) })
    }

    private fun LinearLayout.divider() {
        addView(View(this@MainActivity).apply { setBackgroundColor(border) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply {
                topMargin = dp(4)
                bottomMargin = dp(15)
            })
    }

    private fun space(height: Int) {
        container.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun shape(color: Int, radius: Int, line: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), line)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
}
