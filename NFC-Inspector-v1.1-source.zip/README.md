# NFC Inspector v1.2.1 — BLE diagnostics patch

* Displays BLE scan results even when zero devices are found.
* Allows copying BLE diagnostic report for zero-result scans.
* Displays the status of Android location services and gives a quick shortcut to location settings.
* Updates diagnostics version string to v1.2.1.
* Preserves the NFC scanner, BLE scan-only behavior, and no-network policy.
* Android project source only. APK compilation and device behavior have **not** yet been verified.

# Upload to GitHub

Upload the archive under the name `NFC-Inspector-v1.1-source.zip`, replacing the previous file. The unchanged GitHub Actions workflow reads this exact filename. No YAML update is needed.

## Safety

This project does not authenticate with, modify, or emulate a hotel lock. Bluetooth discovery may transmit standard BLE scan requests; it never attempts GATT connections or commands to nearby BLE devices.
