# NFC Inspector 1.2 — NFC + BLE diagnostic

Native Android app (Kotlin, Android 8.0+, targetSdk 35). This release preserves the previously working NFC scanner and adds a short, foreground-only BLE device discovery mode for **authorized hotel lock observations**.

## New in v1.2

- Two user-triggered 14-second BLE advertisement discovery sessions: **far from door (4–6 m)** and **near door**.
- Shows advertisement name (when broadcast), RSSI median (dBm), number of received scan results, advertised Service UUIDs and manufacturer **company IDs** (not payloads).
- Compares RSSI between sessions for the same observed BLE address. Stronger RSSI near the door is a lead, **not proof** that a device belongs to ORBITA or to the lock.
- Local-only, ephemeral session tokens like `BLE-01`; raw Bluetooth MAC addresses remain in RAM for correlation and are never displayed, exported or persisted.
- Copy text BLE report without MAC addresses. No INTERNET permission. No GPS access, network upload, GATT connections, pairing, protocol injection, key extraction, or lock commands.
- Android's system BLE discovery **may transmit normal radio scan requests**; this is not a raw radio-passive sniffer.
- Discovery automatically ends in 14 seconds or when the app is backgrounded. No background BLE scanning.

## Permissions

- Android 12+: `BLUETOOTH_SCAN`, `BLUETOOTH_CONNECT` (only to check adapter state and optionally read advertised device name), and `ACCESS_FINE_LOCATION` because comparing BLE signal by door may infer proximity. No GPS location is read or stored. This app does **not** use `neverForLocation`, which can suppress some BLE beacon scan results.
- Android 8–11: legacy Bluetooth discovery and `ACCESS_FINE_LOCATION`.
- NFC permission remains as before.

## Test instructions on Xiaomi 17 Ultra / HyperOS Global

1. Export or copy any NFC reports you want to keep. If GitHub's new debug APK uses a different debug signing certificate, Android may require uninstalling the old version; uninstalling deletes app-local NFC history.
2. Enable Bluetooth and (if required by HyperOS) Location services. Open NFC Inspector and grant Nearby Devices + Location when asked.
3. Stand ~4–6 meters from the door and use **1. Замер вдали от двери**. Wait until the scan automatically ends.
4. Move next to the **outside** of the lock and use **2. Замер рядом с замком**. Wait until it ends.
5. Use **Скопировать BLE-отчёт (без MAC)** and share the results. Avoid publicly posting user names or non-lock device details if present in the report.
6. If no BLE device appears, this does not prove that the lock lacks Bluetooth. The module might be absent, disabled, not advertising, or advertising only in an authorized session. Android scan filtering and radio environments also affect results.

## Build via existing GitHub Actions workflow

Your GitHub repository already contains `.github/workflows/build-apk.yml` which extracts a fixed file name. Replace **`NFC-Inspector-v1.1-source.zip`** in the root with the drop-in ZIP supplied for v1.2 (same filename despite newer version inside); commit. The existing workflow extracts and runs `gradle --no-daemon :app:assembleDebug`, then uploads `NFC-Inspector-debug-APK`.

The ZIP also contains the current corrected workflow for standalone use. No Android SDK is available in the source-editing environment; the GitHub Actions run is the compilation check. This release was statically inspected but has not yet been tested on the physical Xiaomi.

## Security boundaries

- This app does not read, write, clone, or emulate a hotel's MIFARE Classic credential. It does not alter the lock.
- Stronger RSSI and matching BLE name alone do not identify the source. Never try to connect to or operate an unknown device based solely on this scan.
